package XXLChess;

class SelectedColourTest {

}
