package XXLChess;

class PieceColourTest {

}
