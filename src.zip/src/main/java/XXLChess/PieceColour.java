package XXLChess;
public enum PieceColour{white,black;}
